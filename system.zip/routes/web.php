<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return view('welcome');
});

// clear cache,view and config
Route::get('/all-clear',function(){
    Artisan::call('cache:clear');
    // Artisan::call('optimize');
    Artisan::call('view:clear');
    Artisan::call('config:cache');
    return "<h1>Cache is Cleared</h1>";
});

Route::get('shippingprocess', 'ShippingController@index');
Route::get('kangaroo', 'ShippingController@kangaroo');
Route::get('tcs', 'ShippingController@tcs');
Route::get('leopard', 'ShippingController@leopard');
Route::get('bluex', 'ShippingController@bluex');
Route::get('fedex', 'ShippingController@fedex');

// FIREBASE
Route::get('firebase', 'FirebaseController@index');
Route::get('testfirebase', 'FirebaseController@testfirebase');

Route::get('testapi/{action}/{timestamp}/{entity}/{id}/{shipping}', 'ApiController@api');

Route::group(['prefix' => 'api', 'testapicar' => 'App\Http\Controllers'], function($app) {	

	$app->post('testapicar', 'TestapicarController@store');
 
	$app->put('testapicar/{id}', 'TestapicarController@update');
 	 
	$app->delete('testapicar/{id}', 'TestapicarController@destory');
 
	$app->get('testapicar', 'TestapicarController@index');

});

Route::get('check/version', function(){
    return phpversion();
});

Route::get('create/store', function () {
    return App\models\stores::create([        
        'store_name' => 'Ego Store',
        'address' => 'Abc Road Xyz Street',
        'store_url' => 'https://wearego.com/',
        'uuid' => uniqid('', true)
    ]);
});

Route::get('uuid', function(){
    return uniqid('', true);
});

Route::resource('store', 'StoresController');
Route::get('order/success', 'OrderfailureController@index');

Route::resource('order/failure', 'OrderfailureController');

Route::post('order/failure/proceed', 'OrderfailureController@proceed');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

<?php

return [

    'curl_urls' => [
        'curl_api_shipped' => env('CURL_API_SHIPPED'),
        'curl_api_shipped_request' => env('CURL_API_SHIPPED_REQUEST'),
        'curl_api_shipped_cancel' => env('CURL_API_SHIPPED_CANCEL'),
    ],

    'navigation_urls' => [
        'home' => env('NAV_HOME'),
        'technify' => env('NAV_TECHNIFY'),
        'store' => env('NAV_STORE'),
        'order_failure' => env('NAV_ORDER_FAILURE'),
        'facebook' => env('NAV_FACEBOOK'),
        'twitter' => env('NAV_TWITTER'),
        'linkdin' => env('NAV_LINKDIN'),
    ],

    'spec_urls' => [
        'store_spec' => env('SPEC_STORE'),
    ],

    'courier_urls' => [
        'kangaroo' => env('URL_KANGAROO'),
        'kangaroo_cacnel' => env('URL_KANGAROO_CANCEL'),
        'leopard' => env('URL_LEOPARD'),
        'leopard_city_list' => env('URL_LEOPARD_CITY_LIST'),
        'tcs' => env('URL_TCS'),
        'shippment_cancel_tcs' => env('URL_SHIPPMENT_CANCEL_TCS'),
        'blueex' => env('URL_BLUEEX'),
        'fedex' => env('URL_FEDEX'),
        'npm' => env('URL_NPM'),
    ],
];

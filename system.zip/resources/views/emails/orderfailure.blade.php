<!DOCTYPE html>
<html>
<head>
	<title>Tehcnify Order Failure</title>
</head>
<body>

	<h5>Hey there TECHNIFY! </h5>
	<p>visit this link <a href="http://system.local/order/failure">Order failure</a> to show your failure order please verify your order</p>

</body>
</html>
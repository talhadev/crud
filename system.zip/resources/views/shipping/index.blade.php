<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<div class="container" style="margin-top: 10px;">

	<div class="content" style="text-align: center;">

		<h1 class="text-muted text-center">Shipping</h1>
		<hr>
		<div class="row">
			<div class="col-md-12">
				<div class="col-md-6">
					<a href="/kangaroo" class="btn btn-primary">Order Push To Knagroo</a>
				</div>
				<div class="col-md-6">
					<a href="/tcs" class="btn btn-primary">Order Push To TCS</a>
				</div>
			</div>				
		</div>

		<br>

		<div class="row">
			<div class="col-md-12">
				<div class="col-md-6">
					<a href="/leopard" class="btn btn-primary">Order Push To Leopard</a>
				</div>
				<div class="col-md-6">
					<a href="/bluex" class="btn btn-primary">Order Push To Blue ex</a>
				</div>
			</div>								
		</div>

		<br>

		<div class="row">
			<div class="col-md-12">
				<div class="col-md-6">
					<a href="/fedex" class="btn btn-primary">Order Push To Fedex</a>
				</div>
				<div class="col-md-6">
					
				</div>
			</div>								
		</div>

	</div>

</div>

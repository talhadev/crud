@extends('layout.master')

@section('template_title')
    Manage Stores
@endsection

@section('content')
	<?php $counter = 1; ?>
	
	<h3 class="text-muted text-center">Stores</h3>

	@if(Session::has('flash_message'))
        <div class="alert alert-success">
            {{ Session::get('flash_message') }}
        </div>
    @endif

    @if(Session::has('error_flash'))
        <div class="alert alert-danger">
            {{ Session::get('error_flash') }}
        </div>
    @endif
	
	@if( count($stores) > 0 )	
		<table class="table table-striped table-hover table-responsive table-condensed table-layout">
		<tr>
			<th>S NO 		  </th>
			<th>Store ID 	  </th>
			<th>Name 	  	  </th>
			<th>Email 	 	  </th>
			<th>Address  	  </th>
			<th>Uuid 		  </th>
			<th>password      </th>
			<th>Store url     </th>
			<th>Support Email </th>
			<th>Action		  </th>
		</tr>
		@foreach( $stores as $store)			

			<tr>
				<td>{{ $counter }}				</td>
				<td>{{ $store->id }}  			</td>
				<td>{{ $store->name }}  		</td>
				<td>{{ $store->email }}  		</td>
				<td>{{ $store->address }}		</td>
				<td>{{ $store->uuid }}			</td>				
				<td>{{ $store->password }}		</td>
				<td>{{ $store->store_url }}		</td>
				<td>{{ $store->support_email }}	</td>
				<td>
					<a href="/store/{{$store->id}}/edit" title="edit store" class="btn btn-primary"><span class="glyphicon glyphicon-pencil"></span></a>
					<a href="/store/{{$store->id}}" title="show complete info" class="btn btn-info"><span class="glyphicon glyphicon-eye-open"></span></a>
	                <a href="javascript:;" class="btn btn-danger" title="delete store" data-toggle="modal" data-target="#dlt_store-{{$store->id}}"><i class="glyphicon glyphicon-trash"></i></a>
				</td>
			</tr>

			<!-- Modal for delete data -->
			<div id="dlt_store-{{$store->id}}" class="modal fade" role="dialog">
			  	<div class="modal-dialog">				    
				    <div class="modal-content">
					    <div class="modal-header text-danger bg-danger">
					    	<button type="button" class="close" data-dismiss="modal">&times;</button>
					        <h4 class="modal-title">Delete Store</h4>
				        </div>
					    <div class="modal-body">
					        <p>Are you sure you want to Delete?</p>
					    </div>
					    <div class="modal-footer">
					        {!! Form::open(['url' => 'store/' . $store->id]) !!}
			                    {!! Form::submit('Yes', ['class' => 'btn btn-danger']) !!}
		               			{!! Form::hidden('_method', 'DELETE') !!}
			                {!! Form::close() !!}
					        <a href="javascript:;" class="btn btn-default" data-dismiss="modal">No</a>
					    </div>
				    </div>
			  	</div>
			</div>

			<?php $counter+=1; ?>
		@endforeach
		</table>

		<!-- pagination -->
		@if( $stores->render() )
			<div class="text-center">
				<div class="pagination">{!! $stores->render() !!}</div>
			</div>
			<div class="clearfix"></div>
		@endif		


	@else
		<p class="text-muted">No store yet</p>
	@endif

	<a href="/store/create" class="btn btn-link">create new store</a>		

@stop
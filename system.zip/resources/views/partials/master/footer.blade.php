<!-- footer content -->
<footer class="navbar-fixed-bottom navbar-default">
    <div class="container-fluid">
        <p class="pull-right">Copyright © 2017 Technify. All rights reserved. |
            <span class="lead"> <i class="fa fa-heart"></i> Technify Shipping</span>
        </p>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->
<?php

return [

	'app'			    => 'Technify Shipping',
	'app2'			    => 'Laravel 5',
	'home'			    => 'Home',
	'login'			    => 'Login',
	'logout'		    => 'Logout',
	'register'		    => 'Register',
	'resetPword'	    => 'Reset Password',
	'toggleNav'		    => 'Toggle Navigation',
    'information'	    => 'Information',
	'profile'		    => 'Profile',
	'editProfile'   	=> 'Edit Profile',
	'createProfile'	    => 'Create Profile',
    'editInformation'	=> 'Edit Information',
    'createInformation'	=> 'Create Information',
    'deleteInformation'	=> 'Delete Information',
    'orderfailure'		=> 'Order',
    'store'				=> 'Store',

];
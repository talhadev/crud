<?php $__env->startSection('template_title'); ?>
    Edit Failure Order
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cssscript'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="com-md-12">			

			<h3 class="text-muted text-center">Edit Order- <?php echo e($store_name->name); ?></h3>

			<?php echo $__env->make('orderfailure.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
			<?php echo Form::model($failure_order, ['method' => 'PATCH', 'action' => ['OrderfailureController@update', $failure_order->id]]); ?>


				<?php echo $__env->make('orderfailure.form', ['sumbitButtonText' => 'Update Order', 'sumbitButtonTextProceed' => 'Update And Proceed'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

			<?php echo Form::close(); ?>			
							
		</div>
	</div>	

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
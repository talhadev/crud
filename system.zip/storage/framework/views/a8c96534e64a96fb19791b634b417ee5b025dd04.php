<?php $__env->startSection('template_title'); ?>
    Signup Store
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cssscript'); ?>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="col-md-12">				

			<h3 class="text-center text-muted">Activate Store</h3>

			<?php if(Session::has('error_flash')): ?>
		        <div class="alert alert-danger col-md-8 col-md-offset-2">
		            <?php echo e(Session::get('error_flash')); ?>

		        </div>
		    <?php endif; ?>

		    <?php echo $__env->make('store.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<?php echo Form::open(['url' => '/store']); ?>


				<?php echo $__env->make('store.form', ['sumbitButtonText' => 'Activate Store'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

			<?php echo Form::close(); ?>			

		</div>
	</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
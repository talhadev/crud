<?php $__env->startSection('template_title'); ?>
    Manage Stores
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php $counter = 1; ?>
	
	<h3 class="text-muted text-center">Stores</h3>

	<?php if(Session::has('flash_message')): ?>
        <div class="alert alert-success">
            <?php echo e(Session::get('flash_message')); ?>

        </div>
    <?php endif; ?>

    <?php if(Session::has('error_flash')): ?>
        <div class="alert alert-danger">
            <?php echo e(Session::get('error_flash')); ?>

        </div>
    <?php endif; ?>
	
	<?php if( count($stores) > 0 ): ?>	
		<table class="table table-striped table-hover table-responsive table-condensed table-layout">
		<tr>
			<th>S NO 		  </th>
			<th>Store ID 	  </th>
			<th>Name 	  	  </th>
			<th>Email 	 	  </th>
			<th>Address  	  </th>
			<th>Uuid 		  </th>
			<th>password      </th>
			<th>Store url     </th>
			<th>Support Email </th>
			<th>Action		  </th>
		</tr>
		<?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			

			<tr>
				<td><?php echo e($counter); ?>				</td>
				<td><?php echo e($store->id); ?>  			</td>
				<td><?php echo e($store->name); ?>  		</td>
				<td><?php echo e($store->email); ?>  		</td>
				<td><?php echo e($store->address); ?>		</td>
				<td><?php echo e($store->uuid); ?>			</td>				
				<td><?php echo e($store->password); ?>		</td>
				<td><?php echo e($store->store_url); ?>		</td>
				<td><?php echo e($store->support_email); ?>	</td>
				<td>
					<a href="/store/<?php echo e($store->id); ?>/edit" title="edit store" class="btn btn-primary"><span class="glyphicon glyphicon-pencil"></span></a>
					<a href="/store/<?php echo e($store->id); ?>" title="show complete info" class="btn btn-info"><span class="glyphicon glyphicon-eye-open"></span></a>
	                <a href="javascript:;" class="btn btn-danger" title="delete store" data-toggle="modal" data-target="#dlt_store-<?php echo e($store->id); ?>"><i class="glyphicon glyphicon-trash"></i></a>
				</td>
			</tr>

			<!-- Modal for delete data -->
			<div id="dlt_store-<?php echo e($store->id); ?>" class="modal fade" role="dialog">
			  	<div class="modal-dialog">				    
				    <div class="modal-content">
					    <div class="modal-header text-danger bg-danger">
					    	<button type="button" class="close" data-dismiss="modal">&times;</button>
					        <h4 class="modal-title">Delete Store</h4>
				        </div>
					    <div class="modal-body">
					        <p>Are you sure you want to Delete?</p>
					    </div>
					    <div class="modal-footer">
					        <?php echo Form::open(['url' => 'store/' . $store->id]); ?>

			                    <?php echo Form::submit('Yes', ['class' => 'btn btn-danger']); ?>

		               			<?php echo Form::hidden('_method', 'DELETE'); ?>

			                <?php echo Form::close(); ?>

					        <a href="javascript:;" class="btn btn-default" data-dismiss="modal">No</a>
					    </div>
				    </div>
			  	</div>
			</div>

			<?php $counter+=1; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>

		<!-- pagination -->
		<?php if( $stores->render() ): ?>
			<div class="text-center">
				<div class="pagination"><?php echo $stores->render(); ?></div>
			</div>
			<div class="clearfix"></div>
		<?php endif; ?>		


	<?php else: ?>
		<p class="text-muted">No store yet</p>
	<?php endif; ?>

	<a href="/store/create" class="btn btn-link">create new store</a>		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>
  	<?php if(trim($__env->yieldContent('template_title'))): ?><?php echo $__env->yieldContent('template_title'); ?> - <?php endif; ?> Technify Shipping
  </title>

	<?php echo $__env->make('partials.master.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <style type="text/css">
    <?php echo $__env->yieldContent('cssscript'); ?>
  </style>

</head>

<body>

    <?php echo $__env->make('partials.master.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container">        

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('partials.master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>  
</body>

</html>


<div class="col-md-8 col-md-offset-2">
    <div class="panel panel-default">
        <div class="panel-heading">
            <?php echo e($sumbitButtonText); ?>

        </div>
        <div class="panel-body">        
            
            <div class="row">
                <div class="col-md-12">
                    <div class="col-md-6">
                    
                        <div class="form-group has-feedback">

                            <?php echo Form::label('name', 'Store Name:'); ?>

                            <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Store Name']); ?>

                            <span class="glyphicon glyphicon-pencil form-control-feedback" aria-hidden="true"></span>

                        </div>

                    </div>
                    <div class="col-md-6">

                        <div class="form-group has-feedback">

                            <?php echo Form::label('email', 'Email:'); ?>

                            <?php echo Form::email('email', null, ['class' => 'form-control', 'placeholder' => 'Email', (isset($store)) ? 'disabled' : '' ]); ?>

                            <span class="glyphicon glyphicon-pencil form-control-feedback" aria-hidden="true"></span>

                        </div>

                    </div>
                </div>
                
            </div>

            <div class="row">
                <div class="col-md-12">                
                    <div class="col-md-12">                

                        <div class="form-group has-feedback">

                            <?php echo Form::label('address', 'Warehouse Address:'); ?>

                            <?php echo Form::text('address', null, ['class' => 'form-control', 'placeholder' => 'Address']); ?>   
                            <span class="glyphicon glyphicon-pencil form-control-feedback" aria-hidden="true"></span>

                        </div>

                    </div>  
                    
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">                
                    <div class="col-md-12">
                        <div class="form-group has-feedback">

                            <?php echo Form::label('store_url', 'Store url:'); ?>

                            <?php echo Form::text('store_url', null, ['class' => 'form-control', 'placeholder' => 'Store url']); ?>

                            <span class="glyphicon glyphicon-pencil form-control-feedback" aria-hidden="true"></span>

                        </div>
                    </div>                    
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">                
                    <div class="col-md-12">
                        <div class="form-group has-feedback">

                            <?php echo Form::label('support_email', 'Support email:'); ?>

                            <?php echo Form::text('support_email', null, ['class' => 'form-control', 'placeholder' => 'Support email']); ?>

                            <span class="glyphicon glyphicon-pencil form-control-feedback" aria-hidden="true"></span>
                            <span class="help-block" style="font-size: 12px;">one or more email comma seprated</span>

                        </div>
                    </div>
                </div>
            </div>

            <?php if(isset($store)): ?>
                <div class="row">
                    <div class="col-md-12">                
                        <div class="col-md-6">
                            <div class="form-group has-feedback">

                                <?php echo Form::label('uuid', 'Uuid:'); ?>

                                <?php echo Form::text('uuid', null, ['class' => 'form-control', 'placeholder' => 'uuid', 'disabled']); ?>

                                <span class="glyphicon glyphicon-pencil form-control-feedback" aria-hidden="true"></span>

                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group has-feedback">

                                <?php echo Form::label('password', 'Password:'); ?>

                                <?php echo Form::text('password', null, ['class' => 'form-control', 'placeholder' => 'password', 'disabled']); ?>

                                <span class="glyphicon glyphicon-pencil form-control-feedback" aria-hidden="true"></span>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
        </div>

        <div class="panel-footer">

            <div class="row">
                <div class="col-md-12">
                    <div class="pull-right">

                        <?php echo Form::submit($sumbitButtonText , ['class' => 'btn btn-primary']); ?>


                    </div>
                </div>
            </div>

        </div>
    </div>
</div>





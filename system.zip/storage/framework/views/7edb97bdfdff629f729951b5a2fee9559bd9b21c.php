<?php $__env->startSection('template_title'); ?>
    Order List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php $sucs_counter = 1; $fail_counter = 1; $cncl_counter = 1; ?>
	
	<h3 class="text-muted text-center">Orders</h3>

	<?php if(Session::has('flash_message')): ?>
        <div class="alert alert-success">
            <strong>Success!</strong> <?php echo e(Session::get('flash_message')); ?>

        </div>
    <?php endif; ?>    

    <?php if(Session::has('error_message')): ?>
        <div class="alert alert-danger">
            <strong>Warning!</strong> <?php echo e(Session::get('error_message')); ?>

        </div>
    <?php endif; ?>   

    <div class="alert alert-danger unselect_order_alert" style="display: none;">
    	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    	<span></span>
    </div>

	<ul class="nav nav-tabs">
		<li><a data-toggle="tab" href="#success"><span class="text-success">Success Orders</span></a></li>
		<li><a data-toggle="tab" href="#cancelled"><span class="text-warning">Cancelled Orders</span></a></li>
		<li class="active"><a data-toggle="tab" href="#failure"><span class="text-danger">Failure Orders</span></a></li>
	</ul>	

    <div class="tab-content">
    	<div id="success" class="tab-pane fade">
			<div class="col-md-12">			
				<h3 class="text-muted text-center">Success Orders</h3>
				<hr/>
				<?php if( count($order_success) > 0 ): ?>	
					<table class="table table-striped table-hover table-responsive table-condensed table-layout">
					<tr>
						<th>S NO 		  	   </th>
						<th>Store 		  	   </th>
						<th>Order ID 	  	   </th>
						<th>Courier Company    </th>
						<th>Order Tracking ID  </th>
						<th>Status 		   	   </th>
						<th>Created at 		   </th>
					</tr>
					<?php $__currentLoopData = $order_success; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_suces): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			

						<tr>
							<td><?php echo e($sucs_counter); ?>					  </td>
							<td><?php echo e(($store->name) ? $store->name : N/A); ?> </td>
							<td><?php echo e($order_suces->order_id); ?>  		  </td>
							<td><?php echo e($order_suces->courier_name); ?>  	  </td>
							<td><a href="http://kangaroo.retailogics.pk/clienteditorder.php?id=<?php echo e($order_suces->order_tracking_id); ?>"><?php echo e($order_suces->order_tracking_id); ?> </a></td>
							<td><?php echo e(($order_suces->status == 1) ? 'success' : ''); ?>	</td>
							<td><?php echo e($order_suces->created_at); ?>		  </td>				
						</tr>

						<?php $sucs_counter+=1; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>

					<!-- pagination -->
					<?php if( $order_success->render() ): ?>
						<div class="text-center">
							<div class="pagination"><?php echo $order_success->render(); ?></div>
						</div>
						<div class="clearfix"></div>
					<?php endif; ?>		

				<?php else: ?>
					<p class="text-muted">No Success order yet</p>
				<?php endif; ?>	
			</div>
		</div>

		<div id="failure" class="tab-pane fade  in active">
			<div class="col-md-12">			
				<h3 class="text-muted text-center">Failure Orders</h3>
				<hr/>
				<?php if( count($order_failure) > 0 ): ?>	

					<div class="checkbox">
						<label class="btn btn-link"><input type="checkbox" value="" id="check_all_emp">Check all</label>
				    </div>

					<table class="table table-striped table-hover table-responsive table-condensed table-layout">
					<tr>
						<th>S NO 		  	   </th>
						<th>Store 	 	  	   </th>
						<th>Order ID 	  	   </th>
						<th>Address 	       </th>
						<th>City 	   		   </th>
						<th>Customer telephone </th>
						<th>Status 		   	   </th>
						<th>Created at 		   </th>						
						<th>Action         	   </th>
					</tr>

					<?php echo Form::open(['url' => '/order/failure/proceed', 'id' => 'order-proceed-form']); ?>


					<?php $__currentLoopData = $order_failure; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_fail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			

						<tr>
							<td>								
								<div class="checkbox text-center">
									<label>
										<input type="checkbox" class="select_order" name="f-ordr-<?php echo e($order_fail->id); ?>" value="<?php echo e($order_fail->id); ?>">
										<?php echo e($fail_counter); ?>	
									</label>
							    </div>						    	
							</td>
							<td><?php echo e($store->name); ?>			  		  </td>
							<td><?php echo e($order_fail->order_id); ?>  		  </td>
							<td><?php echo e(($order_fail->failure_address) ? $order_fail->failure_address : 'N/A'); ?> </td>
							<td><?php echo e(($order_fail->failure_city) ? $order_fail->failure_city : 'N/A'); ?>    	</td>
							<td><?php echo e(($order_fail->telephone)    ? $order_fail->telephone    : 'N/A'); ?>    	</td>
							<td><?php echo e(($order_fail->status == 1) ? 'success' : 'failure'); ?>					</td>
							<td><?php echo e($order_fail->created_at); ?>		  </td>											
							<td>
								<a href="/order/failure/<?php echo e($order_fail->id); ?>/edit" title="show complete info" class="btn btn-primary"><span class="glyphicon glyphicon-pencil"></span></a>
							</td>
						</tr>

						<?php $fail_counter+=1; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php echo Form::close(); ?>

					</table>					

					<a href="#" onclick="proceed()" class="btn btn-primary pull-right">Proceed</a>

					<!-- pagination -->
					<?php if( $order_failure->render() ): ?>
						<div class="text-center">
							<div class="pagination"><?php echo $order_failure->render(); ?></div>
						</div>
						<div class="clearfix"></div>
					<?php endif; ?>		

				<?php else: ?>
					<p class="text-muted">No Failure order yet</p>
				<?php endif; ?>	
			</div>
		</div>

		<div id="cancelled" class="tab-pane fade">
			<div class="col-md-12">			
				<h3 class="text-muted text-center">Cancelled Orders</h3>
				<hr/>
				<?php if( count($order_cancelled) > 0 ): ?>	
					<table class="table table-striped table-hover table-responsive table-condensed table-layout">
					<tr>
						<th>S NO 		  	   </th>
						<th>Store 		  	   </th>
						<th>Order ID 	  	   </th>
						<th>Courier Company    </th>
						<th>Order Tracking ID  </th>
						<th>Status 		   	   </th>
						<th>Created at 		   </th>
					</tr>
					<?php $__currentLoopData = $order_cancelled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_cancel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			

						<tr>
							<td><?php echo e($cncl_counter); ?>					  </td>
							<td><?php echo e(($store->name) ? $store->name : N/A); ?> </td>
							<td><?php echo e($order_cancel->order_id); ?>  		  </td>
							<td><?php echo e($order_cancel->courier_name); ?>  	  </td>
							<td><a href="http://kangaroo.retailogics.pk/clienteditorder.php?id=<?php echo e($order_cancel->order_tracking_id); ?>"><?php echo e($order_cancel->order_tracking_id); ?> </a></td>
							<td><?php echo e(($order_cancel->status == 0) ? 'cancelled' : ''); ?>	</td>
							<td><?php echo e($order_cancel->created_at); ?>		  </td>				
						</tr>

						<?php $cncl_counter+=1; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>

					<!-- pagination -->
					<?php if( $order_success->render() ): ?>
						<div class="text-center">
							<div class="pagination"><?php echo $order_success->render(); ?></div>
						</div>
						<div class="clearfix"></div>
					<?php endif; ?>		

				<?php else: ?>
					<p class="text-muted">No Success order yet</p>
				<?php endif; ?>	
			</div>
		</div>
	</div>
	

<script type="text/javascript">
	$(document).ready(function(){
		$('#check_all_emp').change(function () {    
			if(this.checked){
				$('.select_order').prop("checked", true); 
			}
			else{
				$('.select_order').prop("checked", false);
			}
		});
	});

	function proceed() {
		if($('.select_order').is(':checked')) {			
			$('#order-proceed-form').submit();
		} else {	
			$('.unselect_order_alert').show('5').find('span').html('<strong>Warning!</strong> please select order');			
		}
	}

	$(document).ready(function(){
		var getUrlSegemnt = '<?php echo e(Request::segment(2)); ?>'; 
		if(getUrlSegemnt) {			
			$('.nav-tabs a[href="#' + getUrlSegemnt + '"]').tab('show');
		}
	});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
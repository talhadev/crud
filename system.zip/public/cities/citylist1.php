 'TANDO JAM', 'TDJ',  
'GHAZI ABAD', 'GAD', 
'GHARO', 'GRO',  
'FARROQABAD', 'FAD', 
'HARIPUR', 'HRI', 
 'MIRPUR MATHELO', 'MPM', 
 'HUNZA', 'HNZ', 
 'NASIRABAD', 'NBD',   
 'SARGODAH', 'SGD', 
 'JHELUM', 'JLM', 
 'KASUR', 'KSR',   
 'MIRPUR A.K.', 'QML',   
 'MARDAN', 'MDN', 
 'FEROZA', 'FRZ',    
 'SHUJAABAD', 'SHJ',   
 '', '', 
 '', '', 



['RWP', 'HDD', 'KHI', 'UET', 'MUX', 'SKZ', 'FSD', 'GUJ', 'LHE', 'PEW', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',]
<NewDataSet xmlns="">

    <Table diffgr:id="Table219" msdata:rowOrder="218">
        <CityID>2618</CityID>
        <CityName>ALIPUR</CityName>
        <CityCode>AIP</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table220" msdata:rowOrder="219">
        <CityID>2619</CityID>
        <CityName>LORA LAI</CityName>
        <CityCode>LRI</CityCode>
        <AREA>UET</AREA>
    </Table>
    <Table diffgr:id="Table221" msdata:rowOrder="220">
        <CityID>2620</CityID>
        <CityName>MEHAR</CityName>
        <CityCode>MHR</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table222" msdata:rowOrder="221">
        <CityID>2621</CityID>
        <CityName>USTA MOHAMMAD</CityName>
        <CityCode>USM</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table223" msdata:rowOrder="222">
        <CityID>2622</CityID>
        <CityName> UNKNOWN</CityName>
        <CityCode>AAA</CityCode>
        <AREA>KHI</AREA>
    </Table>
    <Table diffgr:id="Table224" msdata:rowOrder="223">
        <CityID>2623</CityID>
        <CityName>UMERKOT</CityName>
        <CityCode>UKT</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table225" msdata:rowOrder="224">
        <CityID>2624</CityID>
        <CityName>KARAK</CityName>
        <CityCode>KRK</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table226" msdata:rowOrder="225">
        <CityID>2625</CityID>
        <CityName>BAGH</CityName>
        <CityCode>BGH</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table227" msdata:rowOrder="226">
        <CityID>2626</CityID>
        <CityName>YAZMAN MANDI</CityName>
        <CityCode>YZM</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table228" msdata:rowOrder="227">
        <CityID>2627</CityID>
        <CityName>CHOWK AZAM</CityName>
        <CityCode>CAZ</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table229" msdata:rowOrder="228">
        <CityID>2628</CityID>
        <CityName>HATTER</CityName>
        <CityCode>HTR</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table230" msdata:rowOrder="229">
        <CityID>2629</CityID>
        <CityName>TANDO MOHD KHAN</CityName>
        <CityCode>TMK</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table231" msdata:rowOrder="230">
        <CityID>2630</CityID>
        <CityName>FATEH JANG</CityName>
        <CityCode>FTG</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table232" msdata:rowOrder="231">
        <CityID>2631</CityID>
        <CityName>DARA ADM KHEL</CityName>
        <CityCode>DDK</CityCode>
        <AREA>PEW</AREA>
    </Table>
    <Table diffgr:id="Table233" msdata:rowOrder="232">
        <CityID>2632</CityID>
        <CityName>GAWADAR</CityName>
        <CityCode>GWR</CityCode>
        <AREA>KHI</AREA>
    </Table>
    <Table diffgr:id="Table234" msdata:rowOrder="233">
        <CityID>2633</CityID>
        <CityName>KHANEWAL</CityName>
        <CityCode>KWL</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table235" msdata:rowOrder="234">
        <CityID>2634</CityID>
        <CityName>MINCHANABAD</CityName>
        <CityCode>MCD</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table236" msdata:rowOrder="235">
        <CityID>2635</CityID>
        <CityName>DHODHAK</CityName>
        <CityCode>DOK</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table237" msdata:rowOrder="236">
        <CityID>2636</CityID>
        <CityName>KHAIRPUR NATHAN</CityName>
        <CityCode>KNS</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table238" msdata:rowOrder="237">
        <CityID>2637</CityID>
        <CityName>ISSA KHEL</CityName>
        <CityCode>IKL</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table239" msdata:rowOrder="238">
        <CityID>2638</CityID>
        <CityName>JHAT PAT</CityName>
        <CityCode>JPT</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table240" msdata:rowOrder="239">
        <CityID>2639</CityID>
        <CityName>KAMBAR ALI KHAN</CityName>
        <CityCode>KAK</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table241" msdata:rowOrder="240">
        <CityID>2640</CityID>
        <CityName>THULL</CityName>
        <CityCode>THL</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table242" msdata:rowOrder="241">
        <CityID>2641</CityID>
        <CityName>NAUDERO</CityName>
        <CityCode>NDR</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table243" msdata:rowOrder="242">
        <CityID>2642</CityID>
        <CityName>PIRYALO</CityName>
        <CityCode>PJT</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table244" msdata:rowOrder="243">
        <CityID>2643</CityID>
        <CityName>DARGAI</CityName>
        <CityCode>DRG</CityCode>
        <AREA>PEW</AREA>
    </Table>
    <Table diffgr:id="Table245" msdata:rowOrder="244">
        <CityID>2644</CityID>
        <CityName>KOTLI-A.KASHMIR</CityName>
        <CityCode>KLY</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table246" msdata:rowOrder="245">
        <CityID>2645</CityID>
        <CityName>ZHOB</CityName>
        <CityCode>ZOB</CityCode>
        <AREA>UET</AREA>
    </Table>
    <Table diffgr:id="Table247" msdata:rowOrder="246">
        <CityID>2646</CityID>
        <CityName>NOSHKI</CityName>
        <CityCode>NOK</CityCode>
        <AREA>UET</AREA>
    </Table>
    <Table diffgr:id="Table248" msdata:rowOrder="247">
        <CityID>2647</CityID>
        <CityName>GARI KHAIRO</CityName>
        <CityCode>GKR</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table249" msdata:rowOrder="248">
        <CityID>2648</CityID>
        <CityName>FORTE ABBAS</CityName>
        <CityCode>FAB</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table250" msdata:rowOrder="249">
        <CityID>2649</CityID>
        <CityName>TEMARGARAH</CityName>
        <CityCode>TMG</CityCode>
        <AREA>PEW</AREA>
    </Table>
    <Table diffgr:id="Table251" msdata:rowOrder="250">
        <CityID>2650</CityID>
        <CityName>HUMAK</CityName>
        <CityCode>HMK</CityCode>
        <AREA>ISB</AREA>
    </Table>
    <Table diffgr:id="Table252" msdata:rowOrder="251">
        <CityID>2651</CityID>
        <CityName>JHANIAN</CityName>
        <CityCode>JHN</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table253" msdata:rowOrder="252">
        <CityID>2652</CityID>
        <CityName>ABDUL HAKIM</CityName>
        <CityCode>AHT</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table254" msdata:rowOrder="253">
        <CityID>2653</CityID>
        <CityName>DEPAL PUR</CityName>
        <CityCode>DPA</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table255" msdata:rowOrder="254">
        <CityID>2654</CityID>
        <CityName>MAILSI</CityName>
        <CityCode>MLT</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table256" msdata:rowOrder="255">
        <CityID>2655</CityID>
        <CityName>SHORKOT</CityName>
        <CityCode>SQT</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table257" msdata:rowOrder="256">
        <CityID>2656</CityID>
        <CityName>DADU</CityName>
        <CityCode>DDU</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table258" msdata:rowOrder="257">
        <CityID>2657</CityID>
        <CityName>GADOON AMAZAI</CityName>
        <CityCode>GDN</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table259" msdata:rowOrder="258">
        <CityID>2658</CityID>
        <CityName>KHEWRA DANDOT</CityName>
        <CityCode>PDK</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table260" msdata:rowOrder="259">
        <CityID>2659</CityID>
        <CityName>KAROR PAKKA</CityName>
        <CityCode>KPC</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table261" msdata:rowOrder="260">
        <CityID>2660</CityID>
        <CityName>TURBAT</CityName>
        <CityCode>TUK</CityCode>
        <AREA>KHI</AREA>
    </Table>
    <Table diffgr:id="Table262" msdata:rowOrder="261">
        <CityID>2661</CityID>
        <CityName>KHUZDAR</CityName>
        <CityCode>UDR</CityCode>
        <AREA>UET</AREA>
    </Table>
    <Table diffgr:id="Table263" msdata:rowOrder="262">
        <CityID>2662</CityID>
        <CityName>CHAWINDA</CityName>
        <CityCode>CWD</CityCode>
        <AREA>GUJ</AREA>
    </Table>
    <Table diffgr:id="Table264" msdata:rowOrder="263">
        <CityID>2663</CityID>
        <CityName>HAVELLIAN</CityName>
        <CityCode>HVL</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table265" msdata:rowOrder="264">
        <CityID>2664</CityID>
        <CityName>KALA SHAH KAKU</CityName>
        <CityCode>KKU</CityCode>
        <AREA>LHE</AREA>
    </Table>
    <Table diffgr:id="Table266" msdata:rowOrder="265">
        <CityID>2665</CityID>
        <CityName>LIAQUATPUR</CityName>
        <CityCode>LQR</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table267" msdata:rowOrder="266">
        <CityID>2666</CityID>
        <CityName>SHAKAR GARH</CityName>
        <CityCode>SGR</CityCode>
        <AREA>GUJ</AREA>
    </Table>
    <Table diffgr:id="Table268" msdata:rowOrder="267">
        <CityID>2667</CityID>
        <CityName>PATOKI</CityName>
        <CityCode>PTI</CityCode>
        <AREA>LHE</AREA>
    </Table>
    <Table diffgr:id="Table269" msdata:rowOrder="268">
        <CityID>2668</CityID>
        <CityName>PAK PATTAN SHARIF</CityName>
        <CityCode>PPS</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table270" msdata:rowOrder="269">
        <CityID>2669</CityID>
        <CityName>SAMANDRI</CityName>
        <CityCode>SAM</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table271" msdata:rowOrder="270">
        <CityID>2670</CityID>
        <CityName>GILGIT</CityName>
        <CityCode>GIL</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table272" msdata:rowOrder="271">
        <CityID>2671</CityID>
        <CityName>BHAKKAR</CityName>
        <CityCode>BKK</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table273" msdata:rowOrder="272">
        <CityID>2672</CityID>
        <CityName>TANDO ALLAYAR</CityName>
        <CityCode>TDA</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table274" msdata:rowOrder="273">
        <CityID>2673</CityID>
        <CityName>CHENAB NAGAR</CityName>
        <CityCode>AWH</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table275" msdata:rowOrder="274">
        <CityID>2674</CityID>
        <CityName>CHINIOT</CityName>
        <CityCode>IOT</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table276" msdata:rowOrder="275">
        <CityID>2675</CityID>
        <CityName>THATTA</CityName>
        <CityCode>THT</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table277" msdata:rowOrder="276">
        <CityID>2676</CityID>
        <CityName>CHITRAL</CityName>
        <CityCode>CTL</CityCode>
        <AREA>PEW</AREA>
    </Table>
    <Table diffgr:id="Table278" msdata:rowOrder="277">
        <CityID>2677</CityID>
        <CityName>KABIR WALA</CityName>
        <CityCode>KBB</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table280" msdata:rowOrder="279">
        <CityID>2679</CityID>
        <CityName>MUCH</CityName>
        <CityCode>MUH</CityCode>
        <AREA>UET</AREA>
    </Table>
    <Table diffgr:id="Table281" msdata:rowOrder="280">
        <CityID>2680</CityID>
        <CityName>BARKHAN</CityName>
        <CityCode>BKH</CityCode>
        <AREA>UET</AREA>
    </Table>
    <Table diffgr:id="Table282" msdata:rowOrder="281">
        <CityID>2681</CityID>
        <CityName>OLE KHI</CityName>
        <CityCode>OKH</CityCode>
        <AREA>KHI</AREA>
    </Table>
    <Table diffgr:id="Table283" msdata:rowOrder="282">
        <CityID>2682</CityID>
        <CityName>OLE LHE</CityName>
        <CityCode>OLH</CityCode>
        <AREA>LHE</AREA>
    </Table>
    <Table diffgr:id="Table284" msdata:rowOrder="283">
        <CityID>2683</CityID>
        <CityName>OLE RWP</CityName>
        <CityCode>ORW</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table285" msdata:rowOrder="284">
        <CityID>2684</CityID>
        <CityName>SUI</CityName>
        <CityCode>SUI</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table286" msdata:rowOrder="285">
        <CityID>2685</CityID>
        <CityName>KHARAN</CityName>
        <CityCode>KHR</CityCode>
        <AREA>UET</AREA>
    </Table>
    <Table diffgr:id="Table287" msdata:rowOrder="286">
        <CityID>2686</CityID>
        <CityName>SWABI</CityName>
        <CityCode>SWA</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table288" msdata:rowOrder="287">
        <CityID>2687</CityID>
        <CityName>OKARA</CityName>
        <CityCode>OKR</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table289" msdata:rowOrder="288">
        <CityID>2688</CityID>
        <CityName>NOWSHERA</CityName>
        <CityCode>NOW</CityCode>
        <AREA>PEW</AREA>
    </Table>
    <Table diffgr:id="Table290" msdata:rowOrder="289">
        <CityID>2689</CityID>
        <CityName>NAWABSHAH</CityName>
        <CityCode>WNS</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table291" msdata:rowOrder="290">
        <CityID>2690</CityID>
        <CityName>MUZAFFARGARH</CityName>
        <CityCode>MZG</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table292" msdata:rowOrder="291">
        <CityID>2691</CityID>
        <CityName>MUZAFFARABAD AK</CityName>
        <CityCode>MAK</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table293" msdata:rowOrder="292">
        <CityID>2692</CityID>
        <CityName>VEHARI</CityName>
        <CityCode>VRI</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table294" msdata:rowOrder="293">
        <CityID>2693</CityID>
        <CityName>TAXILA</CityName>
        <CityCode>TXL</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table295" msdata:rowOrder="294">
        <CityID>2694</CityID>
        <CityName>WAH</CityName>
        <CityCode>WAH</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table296" msdata:rowOrder="295">
        <CityID>2695</CityID>
        <CityName>TALAGANG</CityName>
        <CityCode>TLG</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table297" msdata:rowOrder="296">
        <CityID>2696</CityID>
        <CityName>SHEIKHUPURA</CityName>
        <CityCode>SRA</CityCode>
        <AREA>LHE</AREA>
    </Table>
    <Table diffgr:id="Table298" msdata:rowOrder="297">
        <CityID>2697</CityID>
        <CityName>SHIKARPUR</CityName>
        <CityCode>SIP</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table299" msdata:rowOrder="298">
        <CityID>2698</CityID>
        <CityName>SAHIWAL</CityName>
        <CityCode>SWL</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table300" msdata:rowOrder="299">
        <CityID>2699</CityID>
        <CityName>SADIQABAD</CityName>
        <CityCode>SDA</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table301" msdata:rowOrder="300">
        <CityID>2700</CityID>
        <CityName>RAHIMYARKHAN</CityName>
        <CityCode>RYK</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table302" msdata:rowOrder="301">
        <CityID>2702</CityID>
        <CityName>UCH SHARIF</CityName>
        <CityCode>UCH</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table303" msdata:rowOrder="302">
        <CityID>2703</CityID>
        <CityName>AMINPUR BANGLOW</CityName>
        <CityCode>AMB</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table304" msdata:rowOrder="303">
        <CityID>2704</CityID>
        <CityName>NAUSHERA</CityName>
        <CityCode>ERA</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table305" msdata:rowOrder="304">
        <CityID>2705</CityID>
        <CityName>ADDA BUN BOSAN</CityName>
        <CityCode>BBA</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table306" msdata:rowOrder="305">
        <CityID>2706</CityID>
        <CityName>RAJANA</CityName>
        <CityCode>RAJ</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table307" msdata:rowOrder="306">
        <CityID>2707</CityID>
        <CityName>DIJKOT</CityName>
        <CityCode>DIJ</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table308" msdata:rowOrder="307">
        <CityID>2708</CityID>
        <CityName>ADDA LAR</CityName>
        <CityCode>ALR</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table309" msdata:rowOrder="308">
        <CityID>2709</CityID>
        <CityName>SANAWAN</CityName>
        <CityCode>SNW</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table310" msdata:rowOrder="309">
        <CityID>2710</CityID>
        <CityName>SUJAWAL</CityName>
        <CityCode>SUJ</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table311" msdata:rowOrder="310">
        <CityID>2711</CityID>
        <CityName>BHIRIA CITY</CityName>
        <CityCode>BRC</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table312" msdata:rowOrder="311">
        <CityID>2712</CityID>
        <CityName>KANDYARO</CityName>
        <CityCode>KND</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table313" msdata:rowOrder="312">
        <CityID>2713</CityID>
        <CityName>CHACHRO</CityName>
        <CityCode>CHO</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table314" msdata:rowOrder="313">
        <CityID>2714</CityID>
        <CityName>HANGU</CityName>
        <CityCode>HNG</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table315" msdata:rowOrder="314">
        <CityID>2715</CityID>
        <CityName>SHINKIARI</CityName>
        <CityCode>SNK</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table316" msdata:rowOrder="315">
        <CityID>2716</CityID>
        <CityName>OGHI</CityName>
        <CityCode>OGI</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table317" msdata:rowOrder="316">
        <CityID>2717</CityID>
        <CityName>LANDIKOTAL</CityName>
        <CityCode>LNK</CityCode>
        <AREA>PEW</AREA>
    </Table>
    <Table diffgr:id="Table318" msdata:rowOrder="317">
        <CityID>2718</CityID>
        <CityName>AHMED PUR LAMMA</CityName>
        <CityCode>APL</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table319" msdata:rowOrder="318">
        <CityID>2719</CityID>
        <CityName>DUNYA PUR</CityName>
        <CityCode>DUN</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table320" msdata:rowOrder="319">
        <CityID>2720</CityID>
        <CityName>BARA KAHU</CityName>
        <CityCode>BRK</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table321" msdata:rowOrder="320">
        <CityID>2721</CityID>
        <CityName>18 HAZARI</CityName>
        <CityCode>AZR</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table322" msdata:rowOrder="321">
        <CityID>2722</CityID>
        <CityName>KHAIPUR TAMEWAL</CityName>
        <CityCode>KTW</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table323" msdata:rowOrder="322">
        <CityID>2723</CityID>
        <CityName>QALANDRABAD</CityName>
        <CityCode>QAL</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table324" msdata:rowOrder="323">
        <CityID>2724</CityID>
        <CityName>PALANDRI</CityName>
        <CityCode>PUL</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table325" msdata:rowOrder="324">
        <CityID>2725</CityID>
        <CityName>GARI YASIN</CityName>
        <CityCode>GYS</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table326" msdata:rowOrder="325">
        <CityID>2726</CityID>
        <CityName>DOKRI</CityName>
        <CityCode>ORI</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table327" msdata:rowOrder="326">
        <CityID>2727</CityID>
        <CityName>WARAH</CityName>
        <CityCode>WRH</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table328" msdata:rowOrder="327">
        <CityID>2728</CityID>
        <CityName>KOT SAMABAH</CityName>
        <CityCode>KSB</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table329" msdata:rowOrder="328">
        <CityID>2729</CityID>
        <CityName>BASIR PUR</CityName>
        <CityCode>BSR</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table330" msdata:rowOrder="329">
        <CityID>2730</CityID>
        <CityName>GHOUS PUR</CityName>
        <CityCode>GPR</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table331" msdata:rowOrder="330">
        <CityID>2731</CityID>
        <CityName>UBARO</CityName>
        <CityCode>URO</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table332" msdata:rowOrder="331">
        <CityID>2732</CityID>
        <CityName>KHIDDER WALA</CityName>
        <CityCode>KDW</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table333" msdata:rowOrder="332">
        <CityID>2733</CityID>
        <CityName>PIPLAN</CityName>
        <CityCode>PLN</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table334" msdata:rowOrder="333">
        <CityID>2734</CityID>
        <CityName>CHASHMA</CityName>
        <CityCode>SMA</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table335" msdata:rowOrder="334">
        <CityID>2735</CityID>
        <CityName>SAHIWAL - FSD</CityName>
        <CityCode>SFD</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table336" msdata:rowOrder="335">
        <CityID>2736</CityID>
        <CityName>NARWALA BANGLA</CityName>
        <CityCode>NLB</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table337" msdata:rowOrder="336">
        <CityID>2737</CityID>
        <CityName>WAN BACHRAN</CityName>
        <CityCode>WBC</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table338" msdata:rowOrder="337">
        <CityID>2738</CityID>
        <CityName>KANDIARI</CityName>
        <CityCode>KDI</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table339" msdata:rowOrder="338">
        <CityID>2739</CityID>
        <CityName>JARWAR</CityName>
        <CityCode>JAR</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table340" msdata:rowOrder="339">
        <CityID>2740</CityID>
        <CityName>ADDA ZAKHEERA</CityName>
        <CityCode>ADZ</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table341" msdata:rowOrder="340">
        <CityID>2741</CityID>
        <CityName>KHAZAKHELA</CityName>
        <CityCode>KZK</CityCode>
        <AREA>PEW</AREA>
    </Table>
    <Table diffgr:id="Table342" msdata:rowOrder="341">
        <CityID>2742</CityID>
        <CityName>RAWAT</CityName>
        <CityCode>RVT</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table343" msdata:rowOrder="342">
        <CityID>2743</CityID>
        <CityName>PINDI GHEB</CityName>
        <CityCode>PGB</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table344" msdata:rowOrder="343">
        <CityID>2744</CityID>
        <CityName>MAKHDOOM AALI</CityName>
        <CityCode>MDA</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table345" msdata:rowOrder="344">
        <CityID>2745</CityID>
        <CityName>BANGLOW GOGERA</CityName>
        <CityCode>GOG</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table346" msdata:rowOrder="345">
        <CityID>2746</CityID>
        <CityName>GOLARCHI</CityName>
        <CityCode>GOL</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table347" msdata:rowOrder="346">
        <CityID>2751</CityID>
        <CityName>KOT MITTHAN</CityName>
        <CityCode>KTM</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table348" msdata:rowOrder="347">
        <CityID>2752</CityID>
        <CityName>DHANOT</CityName>
        <CityCode>DNT</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table349" msdata:rowOrder="348">
        <CityID>2753</CityID>
        <CityName>MUBARAK PUR</CityName>
        <CityCode>MMP</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table350" msdata:rowOrder="349">
        <CityID>2754</CityID>
        <CityName>JAWARIAN</CityName>
        <CityCode>JVR</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table351" msdata:rowOrder="350">
        <CityID>2755</CityID>
        <CityName>MURID WALA</CityName>
        <CityCode>IAA</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table352" msdata:rowOrder="351">
        <CityID>2756</CityID>
        <CityName>MAMUN KANJAN</CityName>
        <CityCode>MKN</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table353" msdata:rowOrder="352">
        <CityID>2757</CityID>
        <CityName>KAMER MOSHANI</CityName>
        <CityCode>KMI</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table354" msdata:rowOrder="353">
        <CityID>2758</CityID>
        <CityName>KALA BAGH</CityName>
        <CityCode>KBH</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table355" msdata:rowOrder="354">
        <CityID>2759</CityID>
        <CityName>HARNOULI</CityName>
        <CityCode>HNL</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table356" msdata:rowOrder="355">
        <CityID>2760</CityID>
        <CityName>KALOOR KOT</CityName>
        <CityCode>OOR</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table357" msdata:rowOrder="356">
        <CityID>2761</CityID>
        <CityName>BARNALA</CityName>
        <CityCode>BRN</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table358" msdata:rowOrder="357">
        <CityID>2762</CityID>
        <CityName>PAHAR PUR</CityName>
        <CityCode>PHP</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table359" msdata:rowOrder="358">
        <CityID>2763</CityID>
        <CityName>SATIANA BANGLA</CityName>
        <CityCode>SBN</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table360" msdata:rowOrder="359">
        <CityID>2764</CityID>
        <CityName>NURPUR THAL</CityName>
        <CityCode>NPT</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table361" msdata:rowOrder="360">
        <CityID>2765</CityID>
        <CityName>KATLANG</CityName>
        <CityCode>KLG</CityCode>
        <AREA>PEW</AREA>
    </Table>
    <Table diffgr:id="Table362" msdata:rowOrder="361">
        <CityID>2766</CityID>
        <CityName>KALAR KAHAR</CityName>
        <CityCode>KLK</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table363" msdata:rowOrder="362">
        <CityID>2767</CityID>
        <CityName>SINJHORO</CityName>
        <CityCode>SJO</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table364" msdata:rowOrder="363">
        <CityID>2768</CityID>
        <CityName>JALALPURPIRWALA</CityName>
        <CityCode>JPP</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table365" msdata:rowOrder="364">
        <CityID>2769</CityID>
        <CityName>BUCHIANA MANDI</CityName>
        <CityCode>BCM</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table366" msdata:rowOrder="365">
        <CityID>2770</CityID>
        <CityName>MANGOWAL</CityName>
        <CityCode>MVL</CityCode>
        <AREA>GUJ</AREA>
    </Table>
    <Table diffgr:id="Table367" msdata:rowOrder="366">
        <CityID>2771</CityID>
        <CityName>HAZRO</CityName>
        <CityCode>HOO</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table368" msdata:rowOrder="367">
        <CityID>2772</CityID>
        <CityName>BUDHLA SANT</CityName>
        <CityCode>BST</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table369" msdata:rowOrder="368">
        <CityID>2773</CityID>
        <CityName>KACHA KHO</CityName>
        <CityCode>KOO</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table370" msdata:rowOrder="369">
        <CityID>2774</CityID>
        <CityName>CHOR CANTT</CityName>
        <CityCode>COC</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table371" msdata:rowOrder="370">
        <CityID>2775</CityID>
        <CityName>DOUR</CityName>
        <CityCode>DOR</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table372" msdata:rowOrder="371">
        <CityID>2776</CityID>
        <CityName>MUSLIM BAGH</CityName>
        <CityCode>LMB</CityCode>
        <AREA>UET</AREA>
    </Table>
    <Table diffgr:id="Table373" msdata:rowOrder="372">
        <CityID>2777</CityID>
        <CityName>DERA ISMAIL KHAN</CityName>
        <CityCode>DIK</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table374" msdata:rowOrder="373">
        <CityID>2778</CityID>
        <CityName>DALBANDIN</CityName>
        <CityCode>DLB</CityCode>
        <AREA>UET</AREA>
    </Table>
    <Table diffgr:id="Table375" msdata:rowOrder="374">
        <CityID>2779</CityID>
        <CityName>SWAT</CityName>
        <CityCode>SWT</CityCode>
        <AREA>PEW</AREA>
    </Table>
    <Table diffgr:id="Table376" msdata:rowOrder="375">
        <CityID>2780</CityID>
        <CityName>CHUNIAN</CityName>
        <CityCode>PTI</CityCode>
        <AREA>LHE</AREA>
    </Table>
    <Table diffgr:id="Table377" msdata:rowOrder="376">
        <CityID>2781</CityID>
        <CityName>TANDO BAGHO</CityName>
        <CityCode>BDN</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table378" msdata:rowOrder="377">
        <CityID>2782</CityID>
        <CityName>SAIDU SHARIF</CityName>
        <CityCode>SWT</CityCode>
        <AREA>PEW</AREA>
    </Table>
    <Table diffgr:id="Table379" msdata:rowOrder="378">
        <CityID>2783</CityID>
        <CityName>ROHRI</CityName>
        <CityCode>SKZ</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table380" msdata:rowOrder="379">
        <CityID>2784</CityID>
        <CityName>NEW SAEEDABAD</CityName>
        <CityCode>HLA</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table381" msdata:rowOrder="380">
        <CityID>2785</CityID>
        <CityName>BHIMBER</CityName>
        <CityCode>BMR</CityCode>
        <AREA>GUJ</AREA>
    </Table>
    <Table diffgr:id="Table382" msdata:rowOrder="381">
        <CityID>2786</CityID>
        <CityName>DUKKI</CityName>
        <CityCode>UKI</CityCode>
        <AREA>UET</AREA>
    </Table>
    <Table diffgr:id="Table383" msdata:rowOrder="382">
        <CityID>2787</CityID>
        <CityName>NAUABAD</CityName>
        <CityCode>TDM</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table384" msdata:rowOrder="383">
        <CityID>2788</CityID>
        <CityName>RAIWAND</CityName>
        <CityCode>RND</CityCode>
        <AREA>LHE</AREA>
    </Table>
    <Table diffgr:id="Table385" msdata:rowOrder="384">
        <CityID>2789</CityID>
        <CityName>MANGA MANDI</CityName>
        <CityCode>BPR</CityCode>
        <AREA>LHE</AREA>
    </Table>
    <Table diffgr:id="Table386" msdata:rowOrder="385">
        <CityID>2790</CityID>
        <CityName>SAMARO</CityName>
        <CityCode>AMO</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table387" msdata:rowOrder="386">
        <CityID>2791</CityID>
        <CityName>MATIARI</CityName>
        <CityCode>MRI</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table388" msdata:rowOrder="387">
        <CityID>2792</CityID>
        <CityName>JAMSHORO</CityName>
        <CityCode>HDD</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table389" msdata:rowOrder="388">
        <CityID>2793</CityID>
        <CityName>KOTRI</CityName>
        <CityCode>HDD</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table390" msdata:rowOrder="389">
        <CityID>2794</CityID>
        <CityName>PETARO</CityName>
        <CityCode>HDD</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table391" msdata:rowOrder="390">
        <CityID>2795</CityID>
        <CityName>TAUNSA SHARIF</CityName>
        <CityCode>KOT</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table392" msdata:rowOrder="391">
        <CityID>2796</CityID>
        <CityName>PIND DADAN KHAN</CityName>
        <CityCode>PDK</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table393" msdata:rowOrder="392">
        <CityID>2797</CityID>
        <CityName>SERAI NAURANG</CityName>
        <CityCode>SNG</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table394" msdata:rowOrder="393">
        <CityID>2798</CityID>
        <CityName>DAULATPUR</CityName>
        <CityCode>WNS</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table395" msdata:rowOrder="394">
        <CityID>2799</CityID>
        <CityName>JALAL PUR BHATTIAN</CityName>
        <CityCode>HZD</CityCode>
        <AREA>GUJ</AREA>
    </Table>
    <Table diffgr:id="Table396" msdata:rowOrder="395">
        <CityID>2800</CityID>
        <CityName>MATLI</CityName>
        <CityCode>MTI</CityCode>
        <AREA>HDD</AREA>
    </Table>
    <Table diffgr:id="Table397" msdata:rowOrder="396">
        <CityID>2801</CityID>
        <CityName>CHOWK SARWER SHAHEED</CityName>
        <CityCode>CSS</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table398" msdata:rowOrder="397">
        <CityID>2802</CityID>
        <CityName>MANKERA</CityName>
        <CityCode>BKK</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table399" msdata:rowOrder="398">
        <CityID>2803</CityID>
        <CityName>BATTGRAM</CityName>
        <CityCode>MNA</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table400" msdata:rowOrder="399">
        <CityID>2804</CityID>
        <CityName>KUNDIAN</CityName>
        <CityCode>MWI</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table401" msdata:rowOrder="400">
        <CityID>2805</CityID>
        <CityName>PABBI</CityName>
        <CityCode>PBI</CityCode>
        <AREA>PEW</AREA>
    </Table>
    <Table diffgr:id="Table402" msdata:rowOrder="401">
        <CityID>2806</CityID>
        <CityName>DERA ALLAHYAR</CityName>
        <CityCode>DAY</CityCode>
        <AREA>SKZ</AREA>
    </Table>
    <Table diffgr:id="Table403" msdata:rowOrder="402">
        <CityID>2807</CityID>
        <CityName>QUAIDABAD</CityName>
        <CityCode>JRD</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table404" msdata:rowOrder="403">
        <CityID>2811</CityID>
        <CityName>RISALPUR</CityName>
        <CityCode>RSP</CityCode>
        <AREA>PEW</AREA>
    </Table>
    <Table diffgr:id="Table405" msdata:rowOrder="404">
        <CityID>2812</CityID>
        <CityName>MANDI FAIZ ABAD</CityName>
        <CityCode>SRA</CityCode>
        <AREA>LHE</AREA>
    </Table>
    <Table diffgr:id="Table406" msdata:rowOrder="405">
        <CityID>2813</CityID>
        <CityName>SAMBRIAL</CityName>
        <CityCode>SAL</CityCode>
        <AREA>GUJ</AREA>
    </Table>
    <Table diffgr:id="Table407" msdata:rowOrder="406">
        <CityID>2814</CityID>
        <CityName>MALAKAND</CityName>
        <CityCode>DRG</CityCode>
        <AREA>PEW</AREA>
    </Table>
    <Table diffgr:id="Table408" msdata:rowOrder="407">
        <CityID>2815</CityID>
        <CityName>SHANGLA</CityName>
        <CityCode>SWT</CityCode>
        <AREA>SWT</AREA>
    </Table>
    <Table diffgr:id="Table409" msdata:rowOrder="408">
        <CityID>2816</CityID>
        <CityName>AJMAN</CityName>
        <CityCode>AJM</CityCode>
        <AREA>DXB</AREA>
    </Table>
    <Table diffgr:id="Table410" msdata:rowOrder="409">
        <CityID>2817</CityID>
        <CityName>AL AIN</CityName>
        <CityCode>ALI</CityCode>
        <AREA>DXB</AREA>
    </Table>
    <Table diffgr:id="Table411" msdata:rowOrder="410">
        <CityID>2818</CityID>
        <CityName>DUBAI</CityName>
        <CityCode>DXB</CityCode>
        <AREA>DXB</AREA>
    </Table>
    <Table diffgr:id="Table412" msdata:rowOrder="411">
        <CityID>2819</CityID>
        <CityName>ABU DHABI</CityName>
        <CityCode>AUH</CityCode>
        <AREA>DXB</AREA>
    </Table>
    <Table diffgr:id="Table413" msdata:rowOrder="412">
        <CityID>2820</CityID>
        <CityName>FUJAIRAH</CityName>
        <CityCode>FUJ</CityCode>
        <AREA>DXB</AREA>
    </Table>
    <Table diffgr:id="Table414" msdata:rowOrder="413">
        <CityID>2821</CityID>
        <CityName>JABELALI</CityName>
        <CityCode>JBL</CityCode>
        <AREA>DXB</AREA>
    </Table>
    <Table diffgr:id="Table415" msdata:rowOrder="414">
        <CityID>2822</CityID>
        <CityName>RAS AL KHAIMAH</CityName>
        <CityCode>RAK</CityCode>
        <AREA>DXB</AREA>
    </Table>
    <Table diffgr:id="Table416" msdata:rowOrder="415">
        <CityID>2823</CityID>
        <CityName>SHARJAH</CityName>
        <CityCode>SHA</CityCode>
        <AREA>DXB</AREA>
    </Table>
    <Table diffgr:id="Table417" msdata:rowOrder="416">
        <CityID>2826</CityID>
        <CityName>CHOHAR JAMALI</CityName>
        <CityCode>THT</CityCode>
        <AREA>KHI</AREA>
    </Table>
    <Table diffgr:id="Table418" msdata:rowOrder="417">
        <CityID>2827</CityID>
        <CityName>KHAIR PUR TAMIANWALI</CityName>
        <CityCode>KTW</CityCode>
        <AREA>MUX</AREA>
    </Table>
    <Table diffgr:id="Table419" msdata:rowOrder="418">
        <CityID>2829</CityID>
        <CityName>DHUDIAL</CityName>
        <CityCode>CKL</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table420" msdata:rowOrder="419">
        <CityID>2832</CityID>
        <CityName>PIR MAHAL</CityName>
        <CityCode>PML</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table421" msdata:rowOrder="420">
        <CityID>2833</CityID>
        <CityName>HARNAI</CityName>
        <CityCode>HNI</CityCode>
        <AREA>UET</AREA>
    </Table>
    <Table diffgr:id="Table422" msdata:rowOrder="421">
        <CityID>2808</CityID>
        <CityName>SHAHDARA</CityName>
        <CityCode>LHE</CityCode>
        <AREA>LHE</AREA>
    </Table>
    <Table diffgr:id="Table423" msdata:rowOrder="422">
        <CityID>2809</CityID>
        <CityName>KOT ABDUL MALIK</CityName>
        <CityCode>LHE</CityCode>
        <AREA>LHE</AREA>
    </Table>
    <Table diffgr:id="Table424" msdata:rowOrder="423">
        <CityID>2830</CityID>
        <CityName>Lower DIR</CityName>
        <CityCode>DRG</CityCode>
        <AREA>PEW</AREA>
    </Table>
    <Table diffgr:id="Table425" msdata:rowOrder="424">
        <CityID>2831</CityID>
        <CityName>BALAKOT</CityName>
        <CityCode>BKT</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table426" msdata:rowOrder="425">
        <CityID>2834</CityID>
        <CityName>JAND</CityName>
        <CityCode>FTG</CityCode>
        <AREA>RWP</AREA>
    </Table>
    <Table diffgr:id="Table427" msdata:rowOrder="426">
        <CityID>2835</CityID>
        <CityName>MANKERA</CityName>
        <CityCode>MKR</CityCode>
        <AREA>FSD</AREA>
    </Table>
    <Table diffgr:id="Table428" msdata:rowOrder="427">
        <CityID>2824</CityID>
        <CityName>UMM AL QUWAIN</CityName>
        <CityCode>UAQ</CityCode>
        <AREA>DXB</AREA>
    </Table>
    <Table diffgr:id="Table429" msdata:rowOrder="428">
        <CityID>2825</CityID>
        <CityName>KHORFAKHAN</CityName>
        <CityCode>KRK1</CityCode>
        <AREA>DXB</AREA>
    </Table>
    <Table diffgr:id="Table430" msdata:rowOrder="429">
        <CityID>2828</CityID>
        <CityName>DADYAL (A.K)</CityName>
        <CityCode>DYL</CityCode>
        <AREA>RWP</AREA>
    </Table>
</NewDataSet>
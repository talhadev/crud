<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Stores extends Model
{    
    protected $table = 'stores';
    
    protected $fillable = [    	
        'name',
        'address',
        'store_url',
        'uuid',
        'email',
        'support_email',
        'password'
    ];
}

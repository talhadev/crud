<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Shipping extends Model
{
    protected $table = 'shippings';
    protected $fillable = [
    	'order_id',
    	'store_id',
    	'orderinfo',    	
    	'courier_name',    	
    	'order_tracking_id',
    	'status'
    ];
}

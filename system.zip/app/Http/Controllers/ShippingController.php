<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Shipping;
use Artisaninweb\SoapWrapper\SoapWrapper;
use DateTime;
use Config;
use App\Models\Stores;
use App\Models\Orderfailure;
use App\Mail\orderfail;
use App\Mail\ordersuccess;
/*use App\Soap\Request\GetConversionAmount;
use App\Soap\Response\GetConversionAmountResponse;*/

class ShippingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {                   
        return view('shipping.index');
    }

    // send pakages to couriers
    public function shipped(Request $request) {              
        
        $timestamp = $this->datetime();
        
        $order_info = json_decode($request->payload, true);   
        
        if( !empty($order_info) ) {                  

          $store_id = $order_info['orderinfo']['store_id'];
          // $order_info['orderinfo']['store_name'] = 'meridukaan';
          
          $city = strtolower($order_info['shipping_address']['city']);
          $address = strtolower($order_info['shipping_address']['address']);

          $data = $this->getcity($address, $city, $store_id);                  
          
          if( !empty($data) && $data !== '' ) {      
            
            $get_store_spec = json_decode($this->getStoreSpec($store_id), true);
            
            $order_info['orderinfo']['store_name'] = $get_store_spec['store_info']['name'];
            $order_info['orderinfo']['store_url']  = $get_store_spec['store_info']['url'];
            
            if(isset($get_store_spec['shippingdetails'])) {
                $companies = $get_store_spec['shippingdetails']['variables']['credentials'];
                
                foreach ($companies as $key => $value) {
                    if( $data['courier_comapny'] == $key ) {
                        $credentials = $value;
                        $origincity  = $get_store_spec['shippingdetails']['variables']['origincity'];
                        break;
                    }
                }                
            }                        
            
            if($timestamp && $credentials && $origincity && $order_info) {
              $shipping_json = [
                'action'      => 'shippingdetails',
                'timestamp'   => $timestamp,
                'credentials' => $credentials,
                'origincity'  => $origincity,
                'datapacket'  => $order_info
              ];
            }
                        
            $curl = curl_init();                        
            curl_setopt_array($curl, array(
                CURLOPT_RETURNTRANSFER => 1,                
                CURLOPT_URL => Config::get('urls.curl_urls.curl_api_shipped').$data['courier_comapny'],
                CURLOPT_USERAGENT => 'Technify Sample cURL Request',
                CURLOPT_POST => 1,
                CURLOPT_POSTFIELDS => array(
                   'payload' => json_encode($shipping_json)
                )
            ));            
            $resp = curl_exec($curl);               
            curl_close($curl);      

            if( $resp == 1 ) {

                $support_email = Stores::select('email', 'support_email')->where('id', $store_id)->first();
                
                if($support_email) {
                    $emails = explode(',', $support_email->support_email);   // send emails for order success
                    foreach ($emails as $email) {
                        \Mail::to($email)->send(new ordersuccess);
                    }
                }                

                return 1;
            } else {
                return 0;
            }

          } else {
              $shipping_json = [
                'action'          => 'orderfailure',
                'timestamp'       => $timestamp,
                'failure_address' => $order_info['shipping_address']['address'],
                'failure_city'    => $order_info['shipping_address']['city'],
                'datapacket'      => $order_info
              ];  
              $order_id        = $shipping_json['datapacket']['orderinfo']['order_id'];
              $store_id        = $shipping_json['datapacket']['orderinfo']['store_id'];
              $telephone       = $shipping_json['datapacket']['customer']['telephone'];
              $failure_address = $shipping_json['failure_address'];
              $failure_city    = $shipping_json['failure_city'];

              $support_email = Stores::select('email', 'support_email')->where('id', $store_id)->first();
              if($support_email) {
                  $emails = explode(',', $support_email->support_email);   // send emails for order failure

                  $check_order_exist = Orderfailure::where('order_id', $order_id)->first();
                  if(!$check_order_exist) {

                      $data = ['order_id' => $order_id, 'store_id' => $store_id, 'failure_address' => $failure_address, 'failure_city' => $failure_city, 'telephone' =>$telephone, 'status' => '0', 'orderinfo' => json_encode($shipping_json)];
                  
                      Orderfailure::create($data);

                  } else {                      

                      $data = ['order_id' => $order_id, 'store_id' => $store_id, 'failure_address' => $failure_address, 'failure_city' => $failure_city, 'orderinfo' => json_encode($shipping_json)];
                      $update_order_failure = Orderfailure::where('order_id', $order_id)->first();                                      
                      $update_order_failure->update($data);

                  }                   

                  foreach ($emails as $key => $value) {
                      
                      // $data = ['order_failure_link' => Config::get('urls.navigation_urls.order_failure')];                      
                      \Mail::to($value)->send(new orderfail);
                                
                  }

                  return 'Some thing wrong your order please check your email or visit <a href="'.Config::get('urls.navigation_urls.order_failure').'">Order failure</a>';
              } else {
                  return 'Store not authorize for Technify';
              }
          }

        } else {            
            return 'order does not exist';
        }          
    }

    // API for kangaroo 
    public function kangaroo(Request $request) {

      $file = 'kangaroo.json';           
      file_put_contents($file, $request->payload, true);   

      $json = json_decode($request->payload, true); 

      $service_url = Config::get('urls.courier_urls.kangaroo');        
      $clientid    = $json['credentials']['clientid'];
      $pass        = $json['credentials']['password'];
      $cname       = $json['datapacket']['customer']['firstname'].' '.$json['datapacket']['customer']['lastname'];
      $caddress    = $json['datapacket']['shipping_address']['address'];
      $cnumber     = $json['datapacket']['customer']['telephone'];
      $amount      = (end($json['datapacket']['total'])['title'] == 'Total') ? end($json['datapacket']['total'])['value'] : null;
      $invoice     = 'demo-'.rand(1000, 9999);        
      $pname       = 'Test Product name';
      $pcode       = 'Test Product Model';
      $city        = $json['origincity'];
      $orderType   = $json['datapacket']['payment_method'][0]["code"];

      $curl = curl_init($service_url);

      $curl_params = array(
          "clientid" => $clientid,
          "pass" => $pass,
          "cname" => $cname,
          "caddress" => $caddress,
          "cnumber" => $cnumber,
          "amount" => $amount,
          "invoice" => $invoice,
          "pname" => $pname,
          "city" => $city,
          "orderType" => $orderType,
      );

      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($curl, CURLOPT_POST, true);
      curl_setopt($curl, CURLOPT_POSTFIELDS, $curl_params);
      $curl_response = curl_exec($curl);
      curl_close($curl);

      $response = json_decode($curl_response, true);
      
      if(isset($response['order id'])){
          $order_tracking_id = $response['order id'];
          $order_id = $json['datapacket']['orderinfo']['order_id'];          
          $store_id = $json['datapacket']['orderinfo']['store_id'];          
          $orderinfo = $request->payload;
          $data = ['order_id' => $order_id, 'store_id' => $store_id, 'orderinfo' => $orderinfo, 'courier_name' =>'kangaroo', 'order_tracking_id' => $order_tracking_id, 'status' => '1'];          
          Shipping::create($data);
          
          $res = 1;
      } else {
          $res = 0;
      }     
      return response()->json($res); 
    }

    // API for TCS 
    public function tcs(Request $request) {         
      // dd($this->datetime());         
      $file = 'tcs.json';      
      file_put_contents($file, $request->payload, true);   

      $json = json_decode($request->payload, true); 

      $client = new \nusoap_client(Config::get('urls.courier_urls.tcs'), true);
      $result = $client->call("InsertData", [
        'userName'             => $json['credentials']['username'], 
        'password'             => $json['credentials']['password'], 
        'costCenterCode'       => $json['credentials']['costCenterCode'], 
        'consigneeName'        => $json['datapacket']['customer']['firstname'].' '.$json['datapacket']['customer']['lastname'],
        'consigneeAddress'     => $json['datapacket']['shipping_address']['address'],
        'consigneeMobNo'       => $json['datapacket']['customer']['telephone'],
        'consigneeEmail'       => $json['datapacket']['customer']['email'],
        'originCityName'       => $json['origincity'],        
        'destinationCityName'  => $json['datapacket']['shipping_address']['city'],
        'pieces'               => $json['datapacket']['cart'][0]['quantity'],
        'weight'               => '0.5',
        'codAmount'            => (end($json['datapacket']['total'])['title'] == 'Total') ? end($json['datapacket']['total'])['value'] : null,
        'custRefNo'            => '1',
        'productDetails'       => '0',
        'fragile'              => 'No',
        'services'             => 'O',
        'remarks'              => 'demo',
        'insuranceValue'       => '0',
      ]);   

      if(isset($result['InsertDataResult'])) {
          $order_tracking_id = $result['InsertDataResult'];
          $order_id = $json['datapacket']['orderinfo']['order_id'];          
          $store_id = $json['datapacket']['orderinfo']['store_id'];          
          $orderinfo = $request->payload;
          $data = ['order_id' => $order_id, 'store_id' => $store_id, 'orderinfo' => $orderinfo, 'courier_name' =>'tcs', 'order_tracking_id' => $order_tracking_id, 'status' => '1'];          
          Shipping::create($data);
          
          $res = 1;
      } else {
          $res = 0;
      }     
      return response()->json($res); 
    }
    
    // LEAOPARD 
    public function leopard(Request $request) {   

      $file = 'leopard.json';      
      file_put_contents($file, $request->payload, true);   
      
      $json = json_decode($request->payload, true); 
    
      $curl_handle = curl_init();
      curl_setopt($curl_handle, CURLOPT_URL, Config::get('urls.courier_urls.leopard')); // Write here Test or Production Link
      curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($curl_handle, CURLOPT_POST, 1);
      curl_setopt($curl_handle, CURLOPT_POSTFIELDS, array(
          'api_key' => $json['credentials']['api_key'],
          'api_password' => $json['credentials']['api_password'],
          'booked_packet_weight' => 2000,                 // weight in grams
          'booked_packet_vol_weight_w' => '',             // OPTIONAL
          'booked_packet_vol_weight_h' => '',
          'booked_packet_vol_weight_l' => '',
          'booked_packet_no_piece' => $json['datapacket']['cart'][0]['quantity'],
          'booked_packet_collect_amount' => (end($json['datapacket']['total'])['title'] == 'Total') ? end($json['datapacket']['total'])['value'] : null,
          'booked_packet_order_id' => $json['datapacket']['orderinfo']['order_id'],         // optinal
          'origin_city' => $this->getLeopardCityId($json['origincity'], $json['credentials']['api_key'], $json['credentials']['api_password']),    // $json['origincity']
          'destination_city' => $this->getLeopardCityId($json['datapacket']['shipping_address']['city'], $json['credentials']['api_key'], $json['credentials']['api_password']),     // $json['datapacket']['shipping_address']['city']
          'shipment_name_eng' => $json['datapacket']['orderinfo']['store_name'],
          'shipment_email' => 'test@gmail.com',
          'shipment_phone' => '03457654321',
          'shipment_address' => 'test address',
          'consignment_name_eng' => $json['datapacket']['customer']['firstname'].' '.$json['datapacket']['customer']['lastname'],
          'consignment_email' => $json['datapacket']['customer']['email'],
          'consignment_phone' => $json['datapacket']['customer']['telephone'],
          'consignment_phone_two' => '',      //OPTIONAL
          'consignment_phone_three' => '',
          'consignment_address' => $json['datapacket']['shipping_address']['address'],
          'special_instructions' => 'Instructions'
      ));

      $buffer = curl_exec($curl_handle);
      curl_close($curl_handle);
      $buffer = json_decode($buffer, true);
      /*$file1 = "leopard1.json";
      file_put_contents($file1, $buffer); */
      if($buffer['status'] == 1){
        $traking_no = $buffer['track_number'];
          $order_id = $json['datapacket']['orderinfo']['order_id'];          
          $store_id = $json['datapacket']['orderinfo']['store_id'];          
          $orderinfo = $request->payload;
          $data = ['order_id' => $order_id, 'store_id' => $store_id, 'orderinfo' => $orderinfo, 'courier_name' =>'leopard', 'order_tracking_id' => $traking_no, 'status' => '1'];          
          Shipping::create($data);
          
          $res = 1;
      } else {
          $res = 0;
      }     
      return response()->json($res); 
    }

    // BLUE EX 
    public function bluex() {
      dd('Blue-Ex');
      $blueEx_service = Config::get('urls.courier_urls.blueex');
      $curl = curl_init();
      curl_setopt($curl, CURLOPT_URL, $blueEx_service );
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1 );
      curl_setopt($curl, CURLOPT_USERPWD, "username:password");
      # Use Blue-Ex Customer Portal Username and Password.
      curl_setopt($curl, CURLOPT_POST, 1 );
      curl_setopt($curl, CURLOPT_POSTFIELDS, [
          'ShipperName' => 'Test Shipper',
          'ShipperAddress' => 'Test Address',
          'ShipperContact' => '03457654321',
          'ShipperEmail' => 'test@gmail.com',
          'ConsigneeName' => 'Test Consignee',
          'ConsigneeAddress' => 'Test Consignee address',
          'ConsigneeContact' => '03457654321',
          'ConsigneeEmail' => 'Consignee@gmail.com',
          'CollectionRequired' => 'Y',
          'ProductDetail' => 'test',
          'ProductValue' => '1200',
          'OriginCity' => 'KHI',
          'DestinationCountry' => 'PK',
          'DestinationCity' => 'LHE',
          'ServiceCode' => 'BG',
          'ParcelType' => 'P',
          'Peices' => '1',
          'Weight' => '1',
          'Fragile' => 'N',
          'ShipperReference' => '9010191', 
          'InsuranceRequire' => 'N', 
          'InsuranceValue' => '', 
          'ShipperComment' => '', 
      ]);
      curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type=application/soap+xml', 'charset=utf-8'));
      $result = curl_exec($curl);

      return $result;
    }

    // TCS soap API  
    public function tcsSoap() {

        /*$this->soapWrapper->add('Tcs', function ($service) {
          $service
            ->wsdl('http://webapp.tcscourier.com/codapi/Service1.asmx?WSDL')
            ->trace(true);*/
            /*->classmap([
              InsertData::class,
              InsertDataResponse::class,
            ]);*/
        /*});*/

        // Without classmap
        /*$response = $this->soapWrapper->call('Tcs.InsertData', [
          'userName'             => 'M2.COD', 
          'password'             => 'police123', 
          'costCenterCode'       => 'CCKHI', 
          'consigneeName'        => 'Ahsan',
          'consigneeAddress'     => 'Address',
          'consigneeMobNo'       => '123456789',
          'consigneeEmail'       => 'ahsan@yahoo.com',
          'originCityName'       => 'KARACHI',
          'destinationCityName'  => 'KARACHI',
          'pieces'               => '0',
          'weight'               => '0.5',
          'codAmount'            => '10000',
          'custRefNo'            => '1',
          'productDetails'       => '0',
          'fragile'              => 'No',
          'services'             => '0',
          'remarks'              => 'demo',
          'insuranceValue'       => '0',
        ]);*/

        //dd($response);

        // With classmap
        /*$response = $this->soapWrapper->call('Tcs.InsertData', [
          new InsertData('USD', 'EUR', '2014-06-05', '1000')
        ]);*/

        dd($response);
    }

    // FEDEX
    public function fedex() {
        // dd($this->datetime());
        // Whoever introduced xml to shipping companies should be flogged
        $xml  = '<?xml version="1.0"?>';
        $xml .= '<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns1="http://fedex.com/ws/rate/v10">';
        $xml .= ' <SOAP-ENV:Body>';
        $xml .= '   <ns1:RateRequest>';
        $xml .= '     <ns1:WebAuthenticationDetail>';
        $xml .= '       <ns1:UserCredential>';
        $xml .= '         <ns1:Key>mVL6VAcj7vY5HsKt</ns1:Key>';
        $xml .= '         <ns1:Password>8fpbgN60OusL2vUy3Lh7USf2d</ns1:Password>';
        $xml .= '       </ns1:UserCredential>';
        $xml .= '     </ns1:WebAuthenticationDetail>';
        $xml .= '     <ns1:ClientDetail>';
        $xml .= '       <ns1:AccountNumber>510087780</ns1:AccountNumber>';
        $xml .= '       <ns1:MeterNumber>118824829</ns1:MeterNumber>';
        $xml .= '     </ns1:ClientDetail>';
        $xml .= '     <ns1:Version>';
        $xml .= '       <ns1:ServiceId>crs</ns1:ServiceId>';
        $xml .= '       <ns1:Major>10</ns1:Major>';
        $xml .= '       <ns1:Intermediate>0</ns1:Intermediate>';
        $xml .= '       <ns1:Minor>0</ns1:Minor>';
        $xml .= '     </ns1:Version>';
        $xml .= '     <ns1:ReturnTransitAndCommit>true</ns1:ReturnTransitAndCommit>';
        $xml .= '     <ns1:RequestedShipment>';
        $xml .= '       <ns1:ShipTimestamp>' . $this->datetime() . '</ns1:ShipTimestamp>';
        $xml .= '       <ns1:DropoffType>REGULAR_PICKUP</ns1:DropoffType>';
        $xml .= '       <ns1:PackagingType>FEDEX_BOX</ns1:PackagingType>';
        $xml .= '       <ns1:Shipper>';
        $xml .= '         <ns1:Contact>';
        $xml .= '           <ns1:PersonName>Test</ns1:PersonName>';
        $xml .= '           <ns1:CompanyName>Test Company</ns1:CompanyName>';
        $xml .= '           <ns1:PhoneNumber>03457654321</ns1:PhoneNumber>';
        $xml .= '         </ns1:Contact>';
        $xml .= '         <ns1:Address>';
        $xml .= '           <ns1:StateOrProvinceCode>TN</ns1:StateOrProvinceCode>';
        $xml .= '           <ns1:PostalCode>38117</ns1:PostalCode>';
        $xml .= '           <ns1:CountryCode>US</ns1:CountryCode>';
        $xml .= '         </ns1:Address>';
        $xml .= '       </ns1:Shipper>';
        $xml .= '       <ns1:Recipient>';
        $xml .= '         <ns1:Contact>';
        $xml .= '           <ns1:PersonName>Ahsan Sheikh</ns1:PersonName>';
        $xml .= '           <ns1:CompanyName>Technify</ns1:CompanyName>';
        $xml .= '           <ns1:PhoneNumber>03467654321</ns1:PhoneNumber>';
        $xml .= '         </ns1:Contact>';
        $xml .= '         <ns1:Address>';
        $xml .= '           <ns1:StreetLines>60 Simcoe St, Toronto, ON M4B 1B3, Canada</ns1:StreetLines>';
        $xml .= '           <ns1:City>Toronto</ns1:City>';
        $xml .= '           <ns1:StateOrProvinceCode>ON</ns1:StateOrProvinceCode>';
        $xml .= '           <ns1:PostalCode>M4B 1B3</ns1:PostalCode>';
        $xml .= '           <ns1:CountryCode>CA</ns1:CountryCode>';
        $xml .= '           <ns1:Residential>true</ns1:Residential>';
        $xml .= '         </ns1:Address>';
        $xml .= '       </ns1:Recipient>';
        $xml .= '       <ns1:ShippingChargesPayment>';
        $xml .= '         <ns1:PaymentType>SENDER</ns1:PaymentType>';
        $xml .= '         <ns1:Payor>';
        $xml .= '           <ns1:AccountNumber>510087780</ns1:AccountNumber>';
        $xml .= '           <ns1:CountryCode>US</ns1:CountryCode>';
        $xml .= '         </ns1:Payor>';
        $xml .= '       </ns1:ShippingChargesPayment>';
        $xml .= '       <ns1:RateRequestTypes>LIST</ns1:RateRequestTypes>';
        $xml .= '       <ns1:PackageCount>1</ns1:PackageCount>';
        $xml .= '       <ns1:RequestedPackageLineItems>';
        $xml .= '         <ns1:SequenceNumber>1</ns1:SequenceNumber>';
        $xml .= '         <ns1:GroupPackageCount>1</ns1:GroupPackageCount>';
        $xml .= '         <ns1:Weight>';
        $xml .= '           <ns1:Units>LB</ns1:Units>';
        $xml .= '           <ns1:Value>400</ns1:Value>';
        $xml .= '         </ns1:Weight>';
        $xml .= '         <ns1:Dimensions>';
        $xml .= '           <ns1:Length>10</ns1:Length>';
        $xml .= '           <ns1:Width>10</ns1:Width>';
        $xml .= '           <ns1:Height>10</ns1:Height>';
        $xml .= '           <ns1:Units>IN</ns1:Units>';
        $xml .= '         </ns1:Dimensions>';
        $xml .= '       </ns1:RequestedPackageLineItems>';
        $xml .= '     </ns1:RequestedShipment>';
        $xml .= '   </ns1:RateRequest>';
        $xml .= ' </SOAP-ENV:Body>';
        $xml .= '</SOAP-ENV:Envelope>';

        $url = 'https://gatewaybeta.fedex.com/web-services/';
        $curl = curl_init($url);

        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $xml);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_TIMEOUT, 30);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        $response = curl_exec($curl);
        
        curl_close($curl);
        dd($response);
        /*$dom = new DOMDocument('1.0', 'UTF-8');
        $dom->loadXml($response);*/
  
    }

    // find address
    public function getcity($address, $city, $store_id) {    
        
        $address = strtolower($address); $city = strtolower($city);

        $data = [];
        $json = json_decode($this->getStoreSpec($store_id), true);        
        
        if( isset($json['shippingdetails']) ) {     
            // $data['city'] = end($json['shippingdetails']['variables']['location'])['cities'][0];              
            // $data['courier_comapny'] = end($json['shippingdetails']['variables']['location'])['courier_name'];        
            
            $cities = $json['shippingdetails']['variables']['location'];                   
            $cities[1]["cities"] = array_map('strtolower', include("cities/".$store_id.".php")); 
            
            foreach ($cities as $key => $value) {       
                foreach ($value['cities'] as $k => $v) {  

                    if( strpos($city, $v || $city == $v) || strpos($address, $v) || $address == $v ) {   

                        $data['city'] = strtolower($v);  
                        $data['courier_comapny'] = strtolower($cities[$key]['courier_name']);                        
                        break;

                    }                    
                }                
            }       
        } 
        
        return $data;     
    }
    
    // get store specification
    public function getStoreSpec($store_id) { 
        $url = Config::get('urls.spec_urls.store_spec').$store_id.'.json';        
        $store_spec = file_get_contents($url);

        return $store_spec;
    }

    // get store specification on local
    public function getStoreSpecLocal($store_id) {
        $file = "stores/" .$store_id. ".json";
        $store_spec = file_get_contents($file);

        return $store_spec;
    }

    // get city id for leopard 
    public function getLeopardCityId($city, $api_key, $api_password) {
        //$data = array('city' => $city, 'api_key' => $api_key, 'api_password' => $api_password);
        $cityid = 'self';        
        $curl_handle = curl_init();
        curl_setopt($curl_handle, CURLOPT_URL, Config::get('urls.courier_urls.leopard_city_list')); // Write here Test or Production Link
        curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl_handle, CURLOPT_POST, 1);
        curl_setopt($curl_handle, CURLOPT_POSTFIELDS, array(
            'api_key' => $api_key,
            'api_password' => $api_password
        ));

        $buffer = curl_exec($curl_handle);
        curl_close($curl_handle);
        $buffer = json_decode($buffer, true);       

        if($buffer['status'] == 1){
            foreach ($buffer['city_list'] as $key => $value) {
                if($value['name'] == ucfirst($city)) {
                    $cityid = $value['id'];
                    break;
                }             
            }
        }        
        return $cityid;
    }

    // cancel shimmpents
    public function cancelShipment(Request $request)
    {        
        $data = json_decode($request->data, true);      

        $store_id = $data['store_id'];  
        $city = $this->getcity($data['address'], $data['city'], $store_id);             

        if( isset($city) && $city ) {

            $get_store_spec = json_decode($this->getStoreSpec($store_id), true);

            if(isset($get_store_spec['shippingdetails'])) {
                $companies = $get_store_spec['shippingdetails']['variables']['credentials'];

                foreach ($companies as $key => $value) {  
                    if( $city['courier_comapny'] == $key ) {    
                        $credentials = $value;
                        break;
                    }
                }
            }                    
            
            $order_credentials = ['order_id' => $data['order_id'], 'store_id' => $store_id, 'credentials' => $credentials];
            
            $curl = curl_init();                        
            curl_setopt_array($curl, array(
                CURLOPT_RETURNTRANSFER => 1,                
                CURLOPT_URL => Config::get('urls.curl_urls.curl_api_shipped_cancel').$city['courier_comapny'],
                CURLOPT_USERAGENT => 'Technify cancel shipment',
                CURLOPT_POST => 1,
                CURLOPT_POSTFIELDS => array(
                   'payload' => json_encode($order_credentials)
                )
            ));            
            $response = curl_exec($curl);  dd($response);
            curl_close($curl);    
        }
    }

    // cancel shipment for TCS
    public function cancelshipmenttcs(Request $request) {        
        
        $data = json_decode($request->payload, true);  
        $order_id = $data['order_id'];
        $store_id = $data['store_id'];
        $filters = ['order_id' => $order_id, 'store_id' => $store_id];
        $traking_data = Shipping::where($filters)->first();        
        
        if( $traking_data && isset($traking_data) ) {
            $traking_no = $traking_data->order_tracking_id;            
        }
        
        if( $data && isset($data) && $traking_no ) {
            $client = new \nusoap_client(Config::get('urls.courier_urls.tcs'), true);
            $result = $client->call("CancelShipment", [
              'userName'             => $data['credentials']['username'], 
              'password'             => $data['credentials']['password'], 
              'consigneeNumber'      => $traking_no, 
            ]);
        }        
        
        if( $result['CancelShipmentResult'] == true ) {
            $update_data = ['status' => 0];
            $traking_data->update($update_data);            
            return 1;
        } else {
            return 0;
        }        
    }

    public function cancelShipmentKangaroo(Request $request)
    {                     
        $data = json_decode($request->payload, true);  
        $order_id = $data['order_id'];
        $store_id = $data['store_id'];
        $filters = ['order_id' => $order_id, 'store_id' => $store_id];
        $traking_data = Shipping::where($filters)->first();
        
        if( $traking_data && isset($traking_data) ) {
            $traking_no = $traking_data->order_tracking_id;            
        }
        
        if( $data && isset($data) && $traking_no ) {
            $url = Config::get('urls.courier_urls.kangaroo_cacnel');
            
            $params = array(
              'clientid' => $data["credentials"]["clientid"],                              
              'pass'     => $data["credentials"]["password"],                         
              'orderid'  => $traking_no,
              'orderidd' => "Order ID: #".$order_id
            );

            $response = json_decode($this->curlRequest($url, $params), true);
            
        }        
        
        if( $response && $response['orderresponse'] == true ) {
            $update_data = ['status' => 0];
            $traking_data->update($update_data);            
            return 1;
        } else {
            return 0;
        }        
    }

    // return current timestamp
    public function datetime() {
        $date = new DateTime();      

        // $timestamp = $date->format('Y-m-dTH:i:s');
        // return $timestamp = "2017-05-26T16:57:44";
        $timestamp = $date->format('Y-m-d H:i:s');
        return $timestamp;
    }

    public function curlRequest($url, $params)
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_RETURNTRANSFER => 1,                
            CURLOPT_URL => $url,
            CURLOPT_USERAGENT => 'Technify',
            CURLOPT_POST => 1,
            CURLOPT_POSTFIELDS => $params
        )); 

        $response = curl_exec($curl);               
        $error = curl_error($curl);   
        curl_close($curl);        
        return $response;
                   
    }
}

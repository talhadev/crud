<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\models\Stores;
use App\models\Shipping;
use App\User;
use auth;

class StoresController extends Controller
{
    /**
    *  if user not login redirect to login page
    */
    public function __construct()
    {    	      	
        $this->middleware('auth', [
            'only' => ['index', 'create', 'store', 'update', 'destroy', 'edit', 'show']
        ]);
    }         

	public function index()
	{	
		if((auth::user()->email !== "ahsans895@gmail.com")){
			dd('You Are Not Authorize To see');
		}
		$stores = Stores::latest()->paginate(20);  
        return view('store.index', compact('stores'));
	}

	public function create()
	{
		return view('store.create');
	}

	public function store(Request $request)
	{
		$this->validate($request, ['name' => 'required',  'address' => 'required',  'email' => 'required|unique:stores|unique:users|email']);
		$input = $request->all();			
		$emailResp = $this->validateEmails($input['support_email']);   
		if(!$emailResp){		
			return redirect('store/create')->with('error_flash', 'Support email invalid')->withInput($request->all());
		}
		$input['password'] = $this->generateRandomString(7);   
		$input['uuid']	   = uniqid('', true);  // generate 23 characters including dot				
		
		//create store and store user
		Stores::create($input);
		$data = ['name' => $input['name'], 'email' => $input['email'], 'password' => bcrypt($input['password'])];
		User::create($data);

		return redirect('/store')->with('flash_message', 'Store/User Added Successfully!');
	}

    public function show($id)
    {
        $store = Stores::findorfail($id);

        return view('store.show', compact('store'));
    }

	public function edit($id)
    {	
        $store = Stores::findorfail($id);

        return view('store.edit', compact('store'));
    }

    public function update(Request $request, $id)
    {        
    	$this->validate($request, ['name' => 'required',  'address' => 'required',  'email' => 'required|email|unique:stores,email,'.$id]);
        $input = $request->all();			
		$emailResp = $this->validateEmails($input['support_email']);   
		if(!$emailResp){		
			return redirect('store/'.$id.'/edit')->with('error_flash', 'Support email invalid')->withInput($request->all());
		}
        $store = Stores::findorfail($id);
        $store->update($request->all());

        return redirect('/store')->with('flash_message', 'Store updated successfully!');
    }

    public function destroy($id)
    {
        $store = Stores::find($id);	
        $store->delete();
        return Redirect::back()->with('flash_message', 'Store deleted successfully');
    }

	public function getLicense(Request $request)
	{			
		$json = json_decode($request->license, true); 
		$store = Stores::where('uuid', $json['license_key'])->first();  

		if(isset($store)){
			file_put_contents('license.json', $store, true); 
			$response = $store->id;
		} else {
			$response = 'false';
		}		
		return $response;
	}

	public function authorizeKey(Request $request)
	{	
		$json = json_decode($request->auth, true);
		$checkkey = Stores::where('uuid', $json['license_key'])->first();
		
		if($checkkey) { 
			return $checkkey->uuid;
		} else {
			return;
		}
	}

	// generate randon numebr and letters
	function generateRandomString($length) {
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $charactersLength = strlen($characters);
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[rand(0, $charactersLength - 1)];
	    }
	    return $randomString;
	}

	public function validateEmails($emails)
	{	
		$emails = str_replace(' ', '', $emails);
		$emails = explode(",",$emails);  
		foreach ($emails as $key => $value) {		
			if(!filter_var($value, FILTER_VALIDATE_EMAIL)) {		 
				return false;
				break;
			} 
		}		
		return true;
	}

	// check order status is completed
	public function orderStatus(Request $request)
	{		
		$data = json_decode($request->payload, true);
		$filter = ['order_id' => $data['order_id'], 'store_id' => $data['store_id']];
		$get_success_order = Shipping::select('order_id', 'status')->where($filter)->first();
		
		if( $get_success_order && $get_success_order->status == '1' ) {
			$response = ['status' => '1', 'order_id' => $get_success_order->order_id];
		} else if( $get_success_order && $get_success_order->status == '2' ) {
			$response = ['status' => '2', 'order_id' => $get_success_order->order_id];
		} else {
			$response = ['status' => '0'];
		}
		
		return $response;
	}
}
